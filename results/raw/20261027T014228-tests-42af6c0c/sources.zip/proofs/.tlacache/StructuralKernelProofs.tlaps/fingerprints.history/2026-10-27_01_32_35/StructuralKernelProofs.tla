------------------------- MODULE StructuralKernelProofs -------------------------
EXTENDS StructuralKernel, TLAPS
THEOREM CurrentCoverage == Coverage
BY SMT DEF Coverage, Trace
THEOREM UniqueProducer == Unique
BY SMT DEF Unique, Trace
THEOREM NoDanglingReference == ReferencesValid
BY SMT DEF ReferencesValid, Edges, Trace, Skeleton
=============================================================================
